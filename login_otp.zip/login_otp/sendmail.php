<?php
include('auth.php');
require './mail/PHPMailerAutoload.php'; // Only include PHPMailerAutoload.php

if(isset($_POST["submit"])){
    // Get the email address from the form
    $CustomerMail = $_POST['email'];

    // Generate a unique reference number
    $ref = mt_rand(1,99999);
    $ref = sprintf("%'.05d\n", $ref);

    // Check if the reference number already exists in the database
    $i = 1;
    while($i == 1){
        $check = $conn->query("SELECT * FROM users WHERE otp = '$ref'")->num_rows;
        if($check > 0){
            $ref = mt_rand(1,99999);
            $ref = sprintf("%'.05d\n", $ref); 
        } else {
            $i = 0;
        }
    }

    // Fetch the OTP from the database for the given email address
    $otp_query = $conn->query("SELECT otp FROM users WHERE email = '$CustomerMail'");
    if ($otp_query->num_rows > 0) {
        $row = $otp_query->fetch_assoc();
        $otp = $row['otp'];

        // Send the OTP via email
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.office365.com';
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = 'tls';
        $mail->Username = 'mooncarwashsystem@outlook.com'; // Fill in with your SMTP username
        $mail->Password = 'Precious@2020.'; // Fill in with your SMTP password

        $mail->setFrom('verifyotp', 'OTP');
        $mail->addAddress($CustomerMail);
        $mail->isHTML(true);
        $mail->Mailer = 'smtp';
        $mail->Subject = 'OTP';
        $mail->Body = 'USE THIS OTP TO CONTINUE: <br>' . $otp;

        if(!$mail->send()){
            echo '<script>alert("Email not sent!");</script>';
        } else {
            echo '<script>alert("OTP SENT!!!");</script>';
        }
    } else {
        echo '<script>alert("Email not found!");</script>';
    }
}
?>
